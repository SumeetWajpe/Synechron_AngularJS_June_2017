﻿
basicModule.controller('basicController', function ($scope) {
    //$scope.Message = "Hello World !";
    $scope.Person = {
        Name: 'Sumeet',
        Location: 'Pune'
    };

});
