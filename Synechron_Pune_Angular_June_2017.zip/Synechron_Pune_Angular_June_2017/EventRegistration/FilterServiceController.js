﻿eventsModule.controller('FilterServiceController', function ($scope,$filter) {

    var durationsFilter = $filter('duration');
    var lowercaseFilter = $filter('lowercase');

    $scope.data = {};
    $scope.data.duration1 = durationsFilter(1);
    $scope.data.duration2 = durationsFilter(2);


});