﻿//var eventDataService = function (){
//    this.getDetails = function () {
//        return  {
//            Name: 'AngularJS',
//            Duration: '3 Days',
//            Price:3000,
//            Location: 'Pune',
//            isFree: false,
//            classToBeApplied: 'Highlight',
//            styleToBeApplied:{backgroundColor:'Yellow'},
//            ImageUrl: 'http://byteclub.fr/img/logo-angular.svg',
//            Sessions: [
//                { Name: 'Basics Of AngularJS', Duration: 1, Level: 'Introductory', Votes: 10,Rating:3.5,Date:new Date() },
//                { Name: 'Using Directives in AngularJS', Duration: 1, Level: 'Intermidiate', Votes: 20, Rating: 3, Date: new Date() },
//                { Name: 'Filters in AngularJS', Duration: 2, Level: 'Intermidiate', Votes: 30, Rating: 4.5, Date: new Date() },
//                { Name: 'Services in AngularJS', Duration: 3, Level: 'Introductory', Votes: 40, Rating: 5, Date: new Date() },
//            { Name: 'Intermidiate knowledge of Directives', Duration: 3, Level: 'Advanced', Votes: 40, Rating: 5, Date: new Date() }

//            ]
//        };
//    }    
//}


//eventsModule.service('eventDataSvc', eventDataService);


//function FactoryDataService() {
//    return {
//        getDetails: function () {
//            return {
//                            Name: 'AngularJS',
//                            Duration: '3 Days',
//                            Price:3000,
//                            Location: 'Pune',
//                            isFree: false,
//                            classToBeApplied: 'Highlight',
//                            styleToBeApplied:{backgroundColor:'Yellow'},
//                            ImageUrl: 'http://byteclub.fr/img/logo-angular.svg',
//                            Sessions: [
//                                { Name: 'Basics Of AngularJS', Duration: 1, Level: 'Introductory', Votes: 10,Rating:3.5,Date:new Date() },
//                                { Name: 'Using Directives in AngularJS', Duration: 1, Level: 'Intermidiate', Votes: 20, Rating: 3, Date: new Date() },
//                                { Name: 'Filters in AngularJS', Duration: 2, Level: 'Intermidiate', Votes: 30, Rating: 4.5, Date: new Date() },
//                                { Name: 'Services in AngularJS', Duration: 3, Level: 'Introductory', Votes: 40, Rating: 5, Date: new Date() },
//                            { Name: 'Intermidiate knowledge of Directives', Duration: 3, Level: 'Advanced', Votes: 40, Rating: 5, Date: new Date() }

//                            ]
//                        };
//        }

//    };
//}


//function FactoryDataService() {
//    return {
//        getDetails: function () {
//            return {
//                Name: 'AngularJS',
//                Duration: '3 Days',
//                Price: 3000,
//                Location: 'Pune',
//                isFree: false,
//                classToBeApplied: 'Highlight',
//                styleToBeApplied: { backgroundColor: 'Yellow' },
//                ImageUrl: 'http://byteclub.fr/img/logo-angular.svg',
//                Sessions: [
//                    { Name: 'Basics Of AngularJS', Duration: 1, Level: 'Introductory', Votes: 10, Rating: 3.5, Date: new Date() },
//                    { Name: 'Using Directives in AngularJS', Duration: 1, Level: 'Intermidiate', Votes: 20, Rating: 3, Date: new Date() },
//                    { Name: 'Filters in AngularJS', Duration: 2, Level: 'Intermidiate', Votes: 30, Rating: 4.5, Date: new Date() },
//                    { Name: 'Services in AngularJS', Duration: 3, Level: 'Introductory', Votes: 40, Rating: 5, Date: new Date() },
//                { Name: 'Intermidiate knowledge of Directives', Duration: 3, Level: 'Advanced', Votes: 40, Rating: 5, Date: new Date() }

//                ]
//            };
//        }

//    };
//}


eventsModule.factory('eventDataSvcWithFactory', function ($http,$q) {
    return {
        getDetails: function (successCB) {   // $http -> get the data from the server !      
            var defer = $q.defer();
            $http({
                method: 'GET',
                //url: 'https://jsonplaceholder.typicode.com/posts'
                url: './Data/JSONEventData.js'
            }).then(function (response) {     
                //successCB(response.data);
                defer.resolve(response.data)
            }, function (err) {
                console.log(err);
                defer.reject('Something went wrong !' + err);
            });
            return defer.promise; // return a promise object (sync)
        }

    };
});

