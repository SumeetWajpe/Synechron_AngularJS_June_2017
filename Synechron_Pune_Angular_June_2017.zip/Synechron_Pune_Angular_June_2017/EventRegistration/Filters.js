﻿eventsModule.filter('duration', function () {

    return function (dur) {
        switch (dur) {
            case 1:
                return '1 Hour';
            case 2:
                return 'Half Day';
            case 3:
                return 'Half Day and a Quarter';
            case 4:
                return 'Full Day';
            default:

        }
    }
});