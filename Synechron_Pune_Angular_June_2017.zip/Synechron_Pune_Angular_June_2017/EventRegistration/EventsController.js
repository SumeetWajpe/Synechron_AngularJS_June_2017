﻿
eventsModule.controller('eventsController', function ($scope, eventDataSvcWithFactory) {
   // $scope.myHTML = "The training is for <script> alert('hi'); </script>";
    //$scope.EventsDetails = {
    //    Name: 'AngularJS',
    //    Duration: '3 Days',
    //    Price:3000,
    //    Location: 'Pune',
    //    isFree: false,
    //    classToBeApplied: 'Highlight',
    //    styleToBeApplied:{backgroundColor:'Yellow'},
    //    ImageUrl: 'http://byteclub.fr/img/logo-angular.svg',
    //    Sessions: [
    //        { Name: 'Basics Of AngularJS', Duration: 1, Level: 'Introductory', Votes: 10,Rating:3.5,Date:new Date() },
    //        { Name: 'Using Directives in AngularJS', Duration: 1, Level: 'Intermidiate', Votes: 20, Rating: 3, Date: new Date() },
    //        { Name: 'Filters in AngularJS', Duration: 2, Level: 'Intermidiate', Votes: 30, Rating: 4.5, Date: new Date() },
    //        { Name: 'Services in AngularJS', Duration: 3, Level: 'Introductory', Votes: 40, Rating: 5, Date: new Date() },
    //    { Name: 'Intermidiate knowledge of Directives', Duration: 3, Level: 'Advanced', Votes: 40, Rating: 5, Date: new Date() }

    //    ]
    //};



    // eventDataSvcWithFactory.getDetails(function (dataFromSrv) {
    //    $scope.EventsDetails = dataFromSrv;
    //});


    var returnedPromise = eventDataSvcWithFactory.getDetails(); // returns a promise
    returnedPromise.then(
        function (data) {
            $scope.EventsDetails = data;
        },
        function (errMsg) {
            console.log(errMsg);
    });


    $scope.companies = [
        { Name: 'Accenture', City: 'Mumbai' },
        { Name: 'Synechron', City: 'Hyderabad' },
        { Name: 'Accenture', City: 'Pune' },
        { Name: 'Synechron', City: 'Pune' },
        { Name: 'Synechron', City: 'Bengaluru' }
    ];

    $scope.isCapitalized = function (dayName) {
        return dayName[0] == dayName[0].toUpperCase();
    };

    $scope.IncrementVotes = function (currSession,evt) {
        currSession.Votes++;
        //console.log(evt.target);
    };

    $scope.DecrementVotes = function (currSession) {
        currSession.Votes--; // changing the model ! 
    };

    $scope.Cities = [
        { Name: 'Mumbai', Speciality: 'Bhel Puri' },
        { Name: 'Hyderabad', Speciality: 'Biryani' },
        { Name: 'Pune', Speciality: 'Vada Pav' },
        { Name: 'Nagpur', Speciality: 'Oranges' }
    ];

    $scope.CityNames = ["Pune","Nagpur","Goa"];
});
