﻿eventsModule.controller('CacheServiceController', function ($scope,myCache) {
    $scope.addToCache = function (key,value) {
        myCache.put(key, value); // predefined
    }

    $scope.readValueFromCache = function (key) {
        return myCache.get(key);  // predefined
    }

    $scope.cacheDetails = function () {
        return myCache.info();  // predefined
    }
   

});