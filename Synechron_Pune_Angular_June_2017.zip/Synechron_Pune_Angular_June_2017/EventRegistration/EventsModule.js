﻿//var eventsModule = angular.module('eventsModule', ['ngSanitize']);

var eventsModule = angular.module('eventsModule', []).factory('myCache', function ($cacheFactory) {
        return $cacheFactory('myCache', { capacity: 3 });
    });