﻿var dirModule = angular.module('dirModule', []);

dirModule.directive('userInformation', function () {
    return {
        //  template: '<h1> AngularJS Directives ! </h1>',
        templateUrl:'TemplateForDirective.html',
        restrict: 'EAC',
        scope:{}
    }
});

dirModule.controller('dirController', function ($scope) {
    $scope.User = {
        Name: 'Sumeet',
        Age:32
    }

});