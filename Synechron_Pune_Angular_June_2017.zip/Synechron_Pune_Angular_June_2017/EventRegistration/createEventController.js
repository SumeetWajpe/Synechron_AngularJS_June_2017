﻿eventsModule.controller('createEventController', function ($scope) {

    $scope.saveEvent = function (evt, formPassed) {

        if (formPassed.$valid) {
            alert(evt.Name + ' saved !');
        }

    }

});