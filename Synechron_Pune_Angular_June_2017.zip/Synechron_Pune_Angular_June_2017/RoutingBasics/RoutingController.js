﻿var routingModule = angular.module('routingModule', ["ngRoute"]);

routingModule.config(function ($routeProvider) {

    $routeProvider.when('/route1/:id/:name/:age', { templateUrl: 'TemplateOne.html', controller: 'routerController' })
                            .when('/route2', { templateUrl: 'TemplateTwo.html', controller: 'routerController' });

});

routingModule.controller('routerController', function ($scope,$routeParams) {

    $scope.Id =    $routeParams.id;

});


